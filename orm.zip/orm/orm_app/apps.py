from django.apps import AppConfig


class OrmAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'orm_app'
